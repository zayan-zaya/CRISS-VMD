
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  


<p align="center">                                                  𝐂𝐑𝐈𝐒𝐒 𝐕𝐄𝐕𝐎-𝐌𝐃 
  

</p>
<p align="center"> 
  <a href="https://whatsapp.com/channel/0029Vb0HIV2G3R3s2II4181g">
    <img alt=Support height="390" src="https://files.catbox.moe/a7p6tw.jpg"> 
    </p>
 
 
 


<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&random=false&width=435&lines=THIS+IS+CRISS VMD+MADE+IN+TANZANIA" alt="Typing SVG" /></a>



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


#### SETUP 


[`FORK`](https://github.com/criss-vevo/CRISS-VMD/fork)


 


[`PAIRING CODE`](https://criss-xbot-x15p.onrender.com/)
 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


#### DEPLOY TO HEROKU 
1. `If You Don't Have An Account On Heroku`

- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

2. `If You Have a Heroku Account`

  - <a align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/criss-vevo/CRISS-VMD/tree/main"> <img src="https://img.shields.io/badge/DEPLOY%20NOW-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


#### DEPLOY ON RENDER 
1. `If You Don't Have An Account On Render`
- <a href="https://dashboard.render.com/register"><img src="https://img.shields.io/badge/CREATE AN ACCOUNT NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

2. `If You Have an account on Render`
- <a href="https://render.com"><img title="Deploy Now" src="https://img.shields.io/badge/DEPLOY NOW-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>







For any issues or to stay updated, use the options below:  

✅ Contact Me on WhatsApp  
[![Contact Me on WhatsApp](https://img.shields.io/static/v1?label=Contact%20Me%20on%20WhatsApp&message=Message&color=25D366&style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/message/NY5RNQQH2DYTN1)  

<br>

✅ Follow My WhatsApp Channel 

[![Follow My WhatsApp Channel](https://img.shields.io/static/v1?label=Follow%20My%20WhatsApp%20Channel&message=follow&color=25D366&style=for-the-badge&logo=whatsapp&logoColor=white)](https://whatsapp.com/channel/0029Vb0HIV2G3R3s2II4181g)  

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

